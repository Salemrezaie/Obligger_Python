#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 12:16:18 2019

@author: salemrezaie
"""

import random

navn=["Jonas, Daniel, Elise"]
alder=[84,53,76]
måned= ["januar, april, desember"]

def registrer(a,b,c):
    return "-15s %2d år gammel %15s" %(navn[a],alder[b],måned[c])
#print(registerer(0,0,0))
i=0
x=0
y=0
z=0

while len(navn):
    print(registrer(x,y,z))
    