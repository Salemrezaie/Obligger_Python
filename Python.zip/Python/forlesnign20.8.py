#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 20 09:17:10 2019

@author: salemrezaie
"""

import numpy as np 
import matplotlib.pyplot as plt

x= np.linspace (0,2,21)
y1= x
y2= x**2
y3= np.sqrt(x)
y4= x**3

plt.subplot(2,2,1)
plt.plot(x,y,'*--b')
plt.title('x')

plt.subplot(2,2,2)
plt.plot(x,y2,'*--g')
plt.title('x^2')

plt.subplot(2,2,2)
plt.plot(x,y3,'*--y')
plt.title('x^3')
