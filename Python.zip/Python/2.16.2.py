#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 12:01:55 2019

@author: salemrezaie
"""

import random

for antall in range(10):
    verdi= random.uniform(-2000,2000)
    print("verdien er %.2e" %(verdi))