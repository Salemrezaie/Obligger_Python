#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 10:18:50 2019

@author: salemrezaie
"""

fila=open("Troktor.txt", 'w')
fila.write( "Jeg vil ha en traktor")
fila.write( "Den skal være blå")
fila.close()

leseFil = open("Troktor.txt", 'r')
lines = leseFil.readlines()
leseFil.close()
print(lines)

for line in lines:
    print (line.rstrip())
    
appFil1 = open("Troktor.txt", 'a')
appFil1.write ("eller gult ")
appFil1.close()


