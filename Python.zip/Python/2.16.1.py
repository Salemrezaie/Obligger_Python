#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 11:15:41 2019

@author: salemrezaie
"""
import random


for atall in range(10):
    verdi=random.uniform(-2000,2000)
    print("%s %.3f"%(antall+1,verdi))

