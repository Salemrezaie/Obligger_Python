#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 20 14:14:20 2019

@author: salemrezaie
"""
import random

sko= ['Adidas', 'puma', 'Nike']
kopi=[]
for i in range(len(sko)):
    print(i,sko[i])
    kopi.append(sko[i])

print ('slutt')
