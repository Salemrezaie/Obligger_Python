#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 15:31:21 2019

@author: salemrezaie
"""

a=(3,6,77)
print(a[0])
print(a[1])
print(a[2])