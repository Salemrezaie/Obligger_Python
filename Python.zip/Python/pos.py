#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 20 10:10:24 2019

@author: salemrezaie
"""

import numpy as np
import matplotlib.pyplot as plt

def pos(t, v0, a=0):
    s=v0*t+0.5*a*t**2
    return s

akse= plt.axes(xlim=(0,20), ylim=(0,10))
vx0 = 10 #starthastighet i x retning
vy0 = 10 #starthastighet i y retning

dt = 0.1
t = 0
ay = -9.81

x= 0
y= 0
#plt.pause(5)
plt.ion()
while y>=0:
    x=pos(t,vx0)
    y=pos(t,vy0,ay)
    akse.scatter([x],[y],c='r')
    #t= t + dt
    t += dt
    plt.pause(dt)
    