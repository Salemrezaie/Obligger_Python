#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 20 14:50:55 2019

@author: salemrezaie
"""

x1=10
x2=20
x3=30

def fun1(x3):
    global x2, x5 
    x1=13
    x2=23
    x4=43
    x5=53 
    print("innenfor: x1 er", x1)
    print("innenfor: x2 er", x2)
    print("innenfor: x3 er", x3)
    print("innenfor: x4 er", x4)
    print("innenfor: x5 er", x5)

fun1(130)
print("utenfor: x1 er", x1)
print("utenfor: x2 er", x2)
print("utenfor: x3 er", x3)
#print("utenfor: x4 er", x4)
print("utenfor: x5 er", x5)
