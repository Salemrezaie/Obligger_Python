#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 18 19:44:38 2019

@author: salemrezaie
"""
navn1=input("Skriv nevn her:  ")
navn2=input("Skriv nevn her:  ")
navn3=input("Skriv nevn her:  ")

names= [navn1, navn2, navn3]
names.sort()

print("sorterte navn")
names.reverse()

for name in names:
    print(name)