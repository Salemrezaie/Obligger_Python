#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 21 09:18:59 2019

@author: salemrezaie
"""

import sympy as sp

x = sp.Symbol('x')
f = x**2-2*x-3
print(f)
print(type(x))

sol = sp.solve(f)
print (sol)

facts= sp.factor(f)
print(facts)

f_der =  sp.diff(f,x)
print(f_der)

f_4= f.subs(x,4)
print(f_4)

y, a= sp.symbols('y,a')
g = 2*x*y - 3*a*x**2
print(g)

g_sol =sp.solve(g,x)
print(g_sol)
g_sim = sp.simplify(g)
print(g_sim)


g2 = g.subs(a,3)
print(g2)

g3= g2.subs(y,x)
print(g3)

g_der_a = sp.diff(g,a)
print(g_der_a)

f_int = sp.integrate(f,x)
print(f)
print(f_int)
g_int = sp.integrate(g,x)
print(g_int)

lign1 = x + y -1
lign2 = x - y + 3

sol = sp.linsolve([lign1, lign2],(x,y))
print(sol)

sol,=sol
x_svar, y_svar= sol
print(x_svar)
print(y_svar)





