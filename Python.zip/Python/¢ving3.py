#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 23 21:23:28 2020

@author: salemrezaie
"""
# Python prosjekt 
import numpy as np
import matplotlib.pyplot as plt

g  = 9.81
y0 = 50
v0 = 0

N = 2000
tmin = 0
tmax = 4

times = np.linspace(tmin, tmax, N)
dt = times[1] - times[0]

y = np.zeros(N)
v = np.zeros(N)
a = np.zeros(N)
e = np.zeros(N)


y[0] = y0
v[0] = v0

for n in range(0 , N - 1, 1):
 
  
    v[n + 1] = v[n] + a[n]*dt
    v[n + 1] = y[n] + v[n]*dt
   # v_t = np.sqrt(m*g/c)
    a[N-1] = -g

fig = plt.figure(1)
plt.ylim (0,1.1*y0)
k1 = plt.plot(times, y, 'b')
plt.xlabel ('t (sekunder) ')
plt.ylabel ('y (meter)')
plt.show

"""
fig = plt.figure(2)
plt.ylim(0,45)
l1 = plt.plot(times, np.abs(v), 'b')
plt.xlabel('t(sekunder)')
plt.ylabel('|v|(meter/sekund)')
plt.show

fig = plt.figure(3)
plt.ylim(8,12)
l1 = plt.plot(times, np.abs(v), 'b')
plt.xlabel('t(sekunder)')
plt.ylabel('|a|(meter/sekund¨^2)')
plt.show

"""
