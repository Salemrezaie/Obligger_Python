#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 16 22:45:28 2019

@author: salemrezaie
"""
""""
import random
tall=random.randint(0,10)
verdi= int(input("Gjett et tall mellom 0 og 10: "))
print(tall)

if verdi > tall:
    print("Du gjettet for høyt")
elif verdi < tall:
    print ("Du gjettet for lavt", "men ikke bli trist prøv igjen")
else:
    print("Du gjettet riktig", "Da ble du glad")
    
"""""
import random

tall=random.randint(1,10)
verdi= int(input("GJett et tall her:   "))
print(tall)

if verdi > tall:
    print("Du gjettet for høyt")
elif verdi < tall:
    print("Du gjettet for lavt")
else:
    print("Du gjettet helt riktig")
4