#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 21 12:22:44 2019

@author: salemrezaie
"""
import random 
svar_list=["Ballong", "Kongsberg", "Universitet", "skolesekk"]
random.shuffle(svar_list)
svar= list(svar_list[0])
 
#print(svar)

display=[]

for i in range(len(display)):
    display[i]="_"

print('    '.join(display))
print()

telle=0

while telle < len(svar):
    gjett=input("gjett et bokstav:  ")
    gjett=gjett.lower()
    print(telle)

for i in rang (len(svar)):
    if svar[i]==gjett :
        display[i]= gjett
        telle= telle + 1
        
    print(' '.join(display))
    print()

print("Du har gjettet riktig")