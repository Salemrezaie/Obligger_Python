#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 20 15:25:11 2019

@author: salemrezaie
"""

import time

def posisjon(t, v0=0, a=0):
    s= v0*t+0.5*a*t**2
    return s

vx0=10
vy0=10
ay=-9.81

tid=0
dt=0.1

sx= 0
sy= 0
while sy >= 0:
    sx = posisjon(tid,vx0)
    yx = posisjon(tid,vy0)
    print("tid:", round(tid, 2), "s x-posjon:", round(sx,2), "m y-posisjon:", sy, "m")
    #print("tid: %4 s x-posijon: %5.1f m y-posisjon: %5.2f m" %(tid, sx, sy))
    tid= tid+ dt
    time.sleep(dt)

print("tid: %4 s x-posijon: %5.1f m y-posisjon: %5.2f m" %(tid, sx, sy))