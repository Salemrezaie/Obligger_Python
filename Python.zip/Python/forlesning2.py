#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 10:35:55 2019

@author: salemrezaie
"""

a = "Ja"
b = "Nei"
c = a+b
print(c)

d= "    Dette er en sting    "
d=d.strip()

print("[",d,"]")
 
e=d.split()
print(e)
 
 
f= d.split("er")
print(f)
 
g= d.count('r')
print(g)

h = d.index('r')
print(h)

i= d.rindex('r')
print(i)

j = d.upper()
print(j)

k = d.lower()
print(k)

l = d.startswith("Det")
print(l)

m= d.endswith("ping")
print(m)


n= d.replace("r", "e")
print(n)

print('Han sa "pass opp"')
print('"Han"', "sa 'pass opp'")