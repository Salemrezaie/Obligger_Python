#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 16 18:42:04 2019

@author: salemrezaie
"""
fornavn=input("Hva er fornavnet ditt?")
etternavn=input("Hva er etternavnet ditt?")
alder=input("Hvor gammel er du?")
aarstall=2019
cirka_bursdag=aarstall-int(alder)
print("Du ble født i%s"%cirka_bursdag)

if int(alder)<50:
    antall=50-int(alder)
    print("Du har%sår igjen før du blir 50 år gammel."%antall)
elif int(alder)>50:
    print("Du er allerede over 50 år gammel.")
    print("Ditt navn er%s%s, du er%sår gammel og du ble født i%s."%(fornavn,etternavn,alder))