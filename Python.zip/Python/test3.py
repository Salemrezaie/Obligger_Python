#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 15:06:17 2019

@author: salemrezaie
"""
"""
print("tekst %i tekst" %(343))
print("tekst %5d tekst" %(343))
print("tekst %d tekst" %(343.999))
print("tekst %i tekst" %(343))
"""
#print("noe %.3f noe" %(43.2324))
#print("noe %3.1f noe" %(00.00002324))


print("Sci %10.2e" %(1234355454545.9845))


