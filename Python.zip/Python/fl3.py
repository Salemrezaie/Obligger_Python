#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 13:15:50 2019

@author: salemrezaie
"""


import numpy as np
import matplotlib.pyplot as plt
x= np.linspace(1,2,11)

x= np.linspace(0,5,11)

y= x**2
y2= np.sqrt(x)
y3=x


print(x)
print(y)
print(y2)

plt.xlabel('x')
plt.ylabel('y')
plt.title("En fin funksjon")

plt.plot(x,y,"r^--", label="X^2")
plt.plot(x,y2,"b.-",label="sqrt(x )")
plt.plot(x,y3,"g*-", label="x")


plt.legend()
plt.show()