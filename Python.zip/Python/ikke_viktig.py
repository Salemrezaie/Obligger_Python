#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 20 17:53:21 2019

@author: salemrezaie
"""
import math as ma
import random

navn=input("Hva heter du? ")
print("Du heter", navn)

alder= input("Hvor gammel er du? ")
#print(alder +13)

int(alder)
print("Om", 13, "år er du", alder+13, "år")