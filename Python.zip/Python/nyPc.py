#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 20 11:56:40 2019

@author: salemrezaie
"""

fil=open("NyPc.txt",'w')
fil.write('"Jeg vil ha en ny pc"\n')
fil.write("Den må vere lett")
fil.close()

lesefil=open("NyPc.txt",'r')
lines=lesefil.readlines()
lesefil.close()
print(lines)

#for line in lines:
  #  print(line.rstrip)
    
appfil= open("NyPc.txt", 'a')
appfil.write("eller en gutt")
appfil.close
print