#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 21 10:15:00 2019

@author: salemrezaie
"""

jeg = {'navn': 'Noe','alder': 27, 'egenskaper':['utvalgt', 'rask']}

print(type(jeg))
print(jeg.keys())
print(jeg['navn'])
print(jeg['egenskaper'])

jeg['navn']= 'Luke'
print(jeg['navn'])

jeg['yrke'] = 'Jedi' 
print(jeg.keys())

if 'skip' in jeg:
    print(jeg['skip'])
    
for key in jeg.keys():
    print('%-15s %s'%(key, jeg[key]))
    
#jeg.pop('alder')
del jeg['alder']
print("------------")

for key in jeg.keys():
    print('%-15s %s'%(key, jeg[key]))
    
print("------------")
mer_om_meg= {'sko':'hvit', 'far': 'usikkert'}
jeg.update(mer_om_meg)

for key in jeg.keys():
    print('%-15s %s'%(key, jeg[key]))
    
mer_om_meg['sko']= 'gul'
print("--------------------")
for key in jeg.keys():
    print('%-15s %s'%(key, jeg[key]))
    