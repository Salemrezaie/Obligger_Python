#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 20 09:37:09 2019

@author: salemrezaie
"""

import numpy as np
import matplotlib.pyplot as plt

antBiler=70
lengder= np.random.uniform(3.5,6, antBiler)
aks = np.random.uniform(4,12, antBiler)
colors= np.random.rand(antBiler)
areal= np.pi * (15*np.random.rand(antBiler))


#plt.plot(lengder, aks, '.b')
plt.scatter(lengder,aks, s=areal, c=colors)
plt.xlabel('billegde')
plt.ylabel('akselerasjon')

