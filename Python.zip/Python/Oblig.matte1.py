# Oppgave 1. abc formolen 

import math
a = float(input("Skriv verdien a: "))
b = float(input("Skriv verdien b: "))
c = float(input("Skriv verdien c: "))

d = b**2-4*a*c 

if d < 0:
    print ("Ingen løsning")
elif d == 0:
    x = (-b+math.sqrt(b**2-4*a*c))/2*a
    print (("Bare en løsning: "), x)
elif a == 0:
    print("Ingen løsning")

else:
    x1 = (-b+math.sqrt((b**2)-(4*(a*c))))/(2*a)
    x2 = (-b-math.sqrt((b**2)-(4*(a*c))))/(2*a)
    print ("Den har to løsninger: ", x1, "og", x2)
2
