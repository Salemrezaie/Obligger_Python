#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 09:20:21 2019

@author: salemrezaie
"""

var1= "dette"
var2= 3.1233456

print(var1, "er pi",var2)
print("tekst %i tekst" %(343))
print("tekst %d tekst" %(343))
print("tekst %s tekst" %(343))
print("tekst %2d tekst" %(343))
print("tekst %8.5d tekst" %(343))
print("tekst %.5d tekst" %(343))
print("tekst %d tekst" %(343.9999))
#print("tekst %d tekst" %(343))

print("tekst %f tekst" %(343.9999))
print("tekst %6.2f tekst" %(343.999))
print("tekst %2.2f tekst" %(343))
print("tekst %6.2f tekst" %(0.0000034))

print("tekst %10.2e tekst" %(0.00000000000034))
print("tekst %10.2e tekst" %(22345666787979879879788.38388979866))

x = 1.60e-19
x2= 1.9e+54

print("tekst %s tekst" %("hei"))
print("tekst %2s tekst" %("hei"))
print("tekst %7s tekst" %("hei"))
print("tekst %-7s tekst" %("hei"))
print("tekst %-7d tekst" %(343))
print("tekst %5s tekst %s mer tekst" %(343, "HALLO"))
