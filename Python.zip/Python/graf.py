#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 20 09:29:15 2019

@author: salemrezaie
"""

import numpy as np 
import matplotlib.pyplot as plt

x= np.linspace (0,2,21)
y1= x
y2= x**2
y3= np.sqrt(x)
y4= x**3

plt.figure("fig1")
plt.plot(x,y1, '.-r')

plt.figure("fig2")
plt.plot(x,y2,'.-b')
plt.plot(x,y4, '.-y')

plt.figure ("fig1")
plt.plot(x,y3, '.-b')
