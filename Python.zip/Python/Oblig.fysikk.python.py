#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan 24 19:54:59 2020

@author: salemrezaie
"""

import numpy as np
import matplotlib.pyplot as plt

g = 9.81 #tyngends akserlasjon
y0 = 50 #starthøyde i meter
v0 = 0 #start hastighet 
e0 = 0


C = 3.85*10**-4 # luft konstant
m = 0.00567 #massen til mynten


#e = (0.5*m*v**2)



N = 2000
tmin = 0
tmax = 5.5

#Oppegave 1
times = np.linspace (tmin,tmax,N) #Definerer 1xN-Array med N-diskrete t-verdier
dt = times[1]-times[0] #Intervall mellom t-verdiene 

#innstralerer y- og -v  og a arrays(en y , en v og en a verdi for hvert t-sekund)
y = np.zeros(N)
v = np.zeros(N)
a = np.zeros(N)
e = np.zeros(N)
e_l = np.zeros(N)

#Setter start verdiene slik at de stemmer med starthøyde og starthastighet

y[0] = y0
v[0] = v0
e[0] = e0


#Oppgave 1
for n in range(0,N-1,1):
    a[n] = -g
    
    v[n+1] = v[n] + a[n]*dt #beregner hastighet et tidssteg fram
    y[n+1] = y[n] + v[n]*dt #beregner posisjon et tidssteg fram
    e[n+1] = (0.5*m*v[n]**2)
    e_l[n+1] = -g+(C*v[n]**2)/m

a[n-1] = -g


#plott av posisjon som funskon av tid

fig = plt.figure(1)
plt.ylim(0,1.1*y0) # Lar -yaksen ha laveste verdi + og høyeste verdi litt over slipp høyde
k1 = plt.plot(times,y, 'b') #plotter possisjonsgrafen
plt.xlabel('t(sekunder)')#symbol og enhet på tidsaksen
plt.ylabel('y (meter)')# symbol og enhet på y-aksen
plt.show


# plott av farten som funksjon av tid
fig = plt.figure(2)
plt.ylim(0,45) # Velger laveste og høyeste verdi på y-aksen
L1 = plt.plot(times,np.abs(v),'b') #Plotter absoluttverdi av hastigheten
plt.xlabel('t (sekunder)')
plt.ylabel('|v| (meter/sekund)')
plt.show


#plott av akselarsjon som funksjon av tid
fig = plt.figure(3)
plt.ylim(8,12)
L1 = plt.plot(times,np.abs(a), 'b')
plt.xlabel (' t (sekunder)')
plt.ylabel('a (meter/sekund^2)')
plt.show

"""

#opgave 2
for n in range(0,N-1,1):
    #e_k = (0.5*m*v**2)
    a[n] = -g
    
    v[n+1] = v[n] + a[n]*dt #beregner hastighet et tidssteg fram
    y[n+1] = y[n] + v[n]*dt #beregner posisjon et tidssteg fram

a[n-1] = -g

for n in range(0,N-1,1):
    a[n] = -g+(C*v[n]**2)/m
    
    v[n+1] = v[n] + a[n]*dt #beregner hastighet et tidssteg fram
    y[n+1] = y[n] + v[n]*dt #beregner posisjon et tidssteg fram
    


fig = plt.figure(1)
plt.ylim(0,1.1*y0) # Lar -yaksen ha laveste verdi + og høyeste verdi litt over slipp høyde
k1 = plt.plot(times,y, 'b') #plotter possisjonsgrafen
plt.xlabel('t(sekunder)')#symbol og enhet på tidsaksen
plt.ylabel('y (meter)')# symbol og enhet på y-aksen
plt.show

# plott av farten som funksjon av tid
fig = plt.figure(2)
plt.ylim(0,15) # Velger laveste og høyeste verdi på y-aksen
L1 = plt.plot(times,np.abs(v),'b') #Plotter absoluttverdi av hastigheten
plt.xlabel('t (sekunder)')
plt.ylabel('|v| (meter/sekund)')
plt.show

#plott av akselarsjon som funksjon av tid
fig = plt.figure(3)
plt.ylim(0,12)
L1 = plt.plot(times,np.abs(a), 'b')
plt.xlabel (' t (sekunder)')
plt.ylabel('a (meter/sekund^2)')
plt.show
"""
#Opgave 3
v_terminal = np.sqrt((m*g)/C)
print("Terminalhastiheten er",(round(v_terminal,3),"m/s"))

#OPPgave 4
#e_k uten luft
#4a
for n in range(0,N-1,1):
    a[n] = -g
    e[n+1] = (0.5*m*v[n]**2)
print ("kenetiske energi uten luftmotstantd: " ,e[1999] , "j") 

#4b
for n in range(0,N-1,1):
    a[n] = -g+(C*v[n]**2)/m
print ("kenetiske energi med luftmotstatnd: " ,e_l[1999] , "j") 
