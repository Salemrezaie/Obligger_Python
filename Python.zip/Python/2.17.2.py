#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 19 15:44:49 2019

@author: salemrezaie
"""
"""
a=("0","1","2","33","44","55")
b=('11','22','33')


print(a+b)
"""

print("%.2e" %(23234343.43434355))
print("%.3e" %(.43434355))