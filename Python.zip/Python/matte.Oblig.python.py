#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 10:17:00 2020

@author: salemrezaie
"""
"""

import cmath
import numpy as np 
import matplotlib.pyplot as plt
import scipy as sp
import math as ma


# Dette er et komplekst objekt. Real  og imaginær del.
# j signaliserer i. Altså imaginær delen. 


lx = []
ly = []
li = []
x0 = 0


def graf(li, ly):
    plt.figure()
    plt.grid()
    plt.plot(li,ly)
    plt.show()
    lx.clear()
    ly.clear()
    
print("oppgave 2&3 a \n")

x0 = 2.3
for i in range(0,5):
   lx.append(x0)
   ly.append(ma.sin(x0))
   li.append(i)
   x0 = x0 - (ma.sin(x0)/ma.cos(x0))
   
   
for i in range (0,5):
    print("iteration ", i , "f(x) = ", ly[i], "x = ", lx[i])

graf(li, ly)

#lx.clear()
#ly.clear()

print('\n')




print("oppgave 2&3 b \n")





x0 = 4

for i in range(0,5):
    lx.append(x0)
    ly.append(ma.sin(x0)-x0)

    x0= x0- (ma.sin(x0)-x0)/(ma.cos(x0)-1)
    


for i in range(0,5):
    print("iteration ", i ,"f(x) = " ,ly[i], "x = ", lx[i]) 

graf(li, ly)    
#lx.clear()
#ly.clear()

print('\n')


print("Oppgave 2&3c \n")





x0 = 0.710

for i in range(0,5):
    lx.append(x0)
    ly.append(ma.sin(x0)-(x0)**5)
    
    x0 = x0 - (ma.sin(x0) -(x0)**5)/(ma.cos(x0) - 5*(x0)**4)



for i in range(0,5):
        print("iteration ", i ,"f(x) = " ,ly[i], "x = ", lx[i]) 

graf(li, ly)


print('\n')

print("oppgave 2#3 d \n")

  
    


x0 = 1

for i in range(0,5):
    lx.append(x0)
    ly.append((x0**4)*ma.sin(x0))
    x0 = x0 - ((x0**4)*ma.sin(x0))/((4*(x0**3))*(ma.sin(x0))+((x0**4)*(ma.cos(x0))))



for i in range(0,5):
        print("iteration ", i ,"f(x) = " ,ly[i], "x = ", lx[i]) 
        
graf(li, ly)

    


print('\n')
print("oppgave 2&3 e \n")



x0 = 2.9

for i in range(0,5):
    lx.append(x0)
    ly.append(((x0)**4) - 16)
    x0 = x0 - (((x0)**4) - 16)/(4*(x0)**3)
    


for i in range(0,5):
        print("iteration ", i ,"f(x) = " ,ly[i], "x = ", lx[i]) 

graf(li, ly)
    

print('\n')
print("oppgave 2&3 f \n")


x0=-0.9
for i in range(0,5):
    lx.append(x0)
    ly.append(x0**10 -1)
    x0 = x0 -(x0**10 -1)/ (10*(x0)**9)
    
for i in range(0,5):
            print("iteration ", i ,"f(x) = " ,ly[i], "x = ", lx[i]) 

graf(li,ly)
"""
#oppgave 1a
"""
import math as ma
import cmath as cma
import numpy as np 
import matplotlib.pyplot as plt
import scipy as sp
import sympy as sy
z= sy.Symbol("z")
i = sy.I
    
def nte_rot(n, re):
   return round(re ** (1/n))
    
def graph_funk(Z1, Z2):
    xmin = -7
    xmax = 7
    ymin =-7
    ymax= 7
    
    plt.figure()
    plt.xlim(xmin, xmax)
    plt.ylim(ymin, ymax)
    plt.plot(Z1, '.', Z2, 'x')
    #plt.plot(Z2, 'x')
    #plt.plot(0,0,'d')
    plt.xlabel('Re(z)')
    plt.ylabel('Im(z)')
    plt.grid()
    plt.show()
        
n = int (input('potensen til z = '))
re = int(input('reelt tall: '))
#complex_calc(n, re)
answer = sy.solve(z**n+re, z)
    
for k in range (0, 3):
    print("Answer", k+1, "=", answer[k])
    c = complex(answer[k])
    graph_funk(c.real, c.imag)
"""    

#Navn Mahram Safdari. Mate oblig. Oppgave 1.1 (opp 2b)
import math 
import cmath
import numpy as np 
import matplotlib.pyplot as plt
import scipy as sp
# Dette er et komplekst objekt. Real  og imaginær del.
# j signaliserer i. Altså imaginær delen. 
z1 = 1+3j

def finn_nullpunkter(a, b, c):
    diskriminant = (b**2)-(4*a*c)
    if diskriminant == 0:
        rot1 = ((-b)+ (cmath.sqrt((b**2)-(4*a*c))))
        print (rot1)
        #plotter real og imaginærdel
        plt.plot(rot1.real, rot1.imag, "P. ")

    else:
        rot1 = ((-b)+(cmath.sqrt((b**2)-(4*a*c)))) 
        rot2 = ((-b)-(cmath.sqrt((b**2)-(4*a*c)))) # /2*a
        print (rot1)
        print(rot2)
        plt.plot([rot1.real, rot2.real], [rot1.imag, rot2.imag], "b. ")
        
        # Bruker taster inn komplekslikning
        print("2. grad reel")
a_0 = complex(float(input("Tast 2. grad reel: ")),float(input("2.  grad imag: ")) ) #0.5, 0
b_0 = complex(float(input("Tast 1. grad reel: ")),float(input("1. grad imag: ")) ) #-3, -1
c_0 = complex(float(input("Tast konst reel: ")),float(input("konst imag: ")) ) # 4, -1



#b_0 = complex(input("1.grad reel: ", "1.grad imag: "))
#c_0 = complex(input("konstant reel: ", "konstant imag: "))
 #kjører funksjonen
finn_nullpunkter(a_0, b_0, c_0)
plt.show()