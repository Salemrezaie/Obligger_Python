#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 30 12:13:15 2019

@author: salemrezaie
"""
print("Velkommen til regnekalkulaturen")

start_belop = int(input("Hva er startbelopet? "))
rente = int(input("Hva er renten? "))
antall_aar = int(input("Hvor mange år? "))

rente = (100 + rente)/ 100

for aar in range(1,antall_aar +1): 
    belop = start_belop * rente ** aar
    belop= round(belop,2)
    print("Etter {} ar har du {} korner.".format(aar, belop))