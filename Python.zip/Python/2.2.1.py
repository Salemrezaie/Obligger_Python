#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep  6 12:18:35 2019

@author: salemrezaie
"""
"""
#oppgave 2.2.1
a = 2*3-4/2*2
b = (1-3)*(-3)/(2*2)
c = 2*3**2/2
d = 1/2**3-4-8/2*4
e = 1/2**3-4-8/2*4
print(a)
print(b)
print(c)
print(d)
print(e)


# oppgave 2.2.2
a=3 
b= 12
areal = (a*b)
print(areal)

#2.2.3
a=4
b = 5
omkrets = 2*(a+b)
print(omkrets)

#2.2.4
x= 15/3
print(x)


#2.2.5
omkrets = ((3.14*3**2)/2)
print(omkrets)


#2.3.1
a = float('7.3')
b = float('30.1')
print(round(a*b,2))

#2.3.3

a = 3,14
b = "pi er"
c =b,a
print(c) # Hvor for fikk vi prantes rundt teksten?

# 2.4.1
import math 
grader = 90
radian_verdi = math.radians(grader)
print(math.sin(radian_verdi))
print(math.cos(radian_verdi)) #fikk feil svar

#2.4.2
import random as ra
print(ra.random())
print(ra.uniform(-5,5))
print(ra.uniform(-2,18))


#2.4.3
print(ra.randint(0,9))
print(ra.randint(-5,5))
print(ra.randint(-2,18))

import random as ra
import math
#2.4.4
a= 35
sin_verdi= math.sin(a)
cos_verdi = math.cos(a)
sin_opphøyd = sin_verdi**2
cos_opphøyd = cos_verdi**2
print( sin_opphøyd + cos_opphøyd)

#2.4.5
import math
radian = 2.3
sin = math.sin(math.radians(radian))
cos = math.cos(math.radians(radian))
print(round(sin,2))
print(round(cos,3))

#2.4.6
import math
print(math.sqrt(256))

#2.5.1
import math
tall = input("Velg et tall: ")
tall1 = float(tall)
sqrt_pi = math.sqrt(tall1)
totall = sqrt_pi*3.14
print(totall)


#2.6.1
fornavn= input("Hva er fornavnet ditt? ")
etternavn = input("Hva er etter navnet ditt? ")
alder = input("Hvor gammel er du? ")
aarstall = 2019

circa_bursdag = aarstall-int(alder)
print("Du ble født %s" %(circa_bursdag))

if int(alder)< 50:
    antall = 50-int(alder)
    print("Du har %s år igjen til du blir 50 år gammel." %(antall))
elif int(alder)> 50:
    print("Du er allrede 50 år gammel")
    print("Ditt navn er %s %s, du er % gammel og ble født i%s." %(fornavn,etternavn, alder,circa_bursdag))

#2.6.2
import random
navn = input("Hva heter du? ")
alder= random.randint(15,35)
print ("Ditt navn er",navn,"og du er ",alder,"år gammel")

#2.7.2
tall1 = float(input("skrive tall 1: "))
tall2 = float(input("skrive tall 2: "))
tall3 = float(input("skrive tall 3: "))
maksverdi = max(tall1,tall2,tall3)

if tall1 == maksverdi:
    vinner= ("tall1")
elif tall2 == maksverdi:
    vinner=("tall2")
elif tall3 == maksverdi:
    vinner = ("tall3")
print("vinneren er",vinner,"med talverdi",maksverdi)

#2.7.2
import random
gjett= int(input("gjett ett tall mellom 1 og 10: "))
tall= random.randint(0,11)

if gjett == tall:
    print("Du gjettet riktig, nå ble du glad vel")
elif gjett < tall:
    print("Du gjettet for lavt")
    
elif gjett> tall:
    print(" Du gjettet for høyt")
print(tall)


#2.6.3
import random
kast1= random.randint(1,1)
kast2= random.randint(1,1)
kast3= random.randint(1,1)
tre_kast=(kast1,kast2,kast3)

if kast1== kast2:
    print("Du fikk to like")
elif kast1== kast3:
    print("Du fikk to like")
elif kast2==kast3:
    print("Du fikk to like")
elif kast1 == kast2 or kast1 ==kast3 or kast2==kast3:
    print("Du fikk alle like!")
else:
    print("Du fikk ingen like")
    
print(tre_kast)

#2.8.1
navn1= ["Jonas","Daniel","Elina"]
#navn2= "Daniel"
#navn3= "Elina"
#navn=[navn1,navn2,navn3]
navn1.reverse()
#navn.append("Julle")
#navn.pop()
print(navn1)

#2.8.3
liste= list(range(5,18,3))

print(liste)

#Oppgave 2.8.4
import random
liste= list(range(6))
liste.pop(3)
liste.pop(2)
liste.append(3)
liste.sort()
liste.insert(2,5)
liste.index(5)
forste_index= liste.index(5)
andre_index2= liste[forste_index+1:].index(5)+ forste_index2+1
print(forste_index)
print(andre_index2)
print(liste)


#Oppgave 2.8.5
liste= list(range(11,78,11))
liste1= list(range(33,56,11))
print(liste)
print(liste1)

#oppgave 2.9.2
import random

n4 = 0
n3 = 0
n2 = 0
n1 = 0
for kast in range(100):
    tall = random.randint(1,4)
    print("kast nr", kast1 + 1,"ble", tall)
    if tall == 4:
        n4 = n4 + 1
    elif tall ==3:
        n3 = n3 + 1
    elif tall == 2:
        n2 = n2 + 1
    elif tall==1:
        n1 = n1 +1
print(" Det le totalt", n4, "firere og", n3, "trere",n2, "toere",n1,"enere.")

#oppgave 2.9.3
import random
tall= list(range(100))
print()
"""
#oppgave 2.10.1

import random as ra
antall_opg = int(input("hvor magne oppgaver ønsker du å gjøre? "))
antall_png = int(input("hvor mange poeng vil du gi per oppgave? "))
minuspoeng = int(input("Hvor mange poen skal trekkes ved feil? "))
laveste_tall = int(input("Laveste tall fra gangetallen: "))
hoyeste_tall = int(input("Høyeste tall fra gangetabellen: "))
print( "Du får %s poeng for riktige svar og -%s for freil svar." % (antall_png,minuspoeng))

feil_antall = 0
riktig_antall = 0
opgnr= 0

while true:
    a= ra.randint(laveste_tall, hoyeste_tall)
    b= ra.randint(laveste_tall, hoyeste_tall)
    print("Hva er %s * %s?" %(a,b))
    bruker_svar = int(input("Hva er svaret?"))
    
    if svar == bruker_svar:
        riktig_antall +=1
        opgnr +=1
    else:
        feil_antall +=1
        opgnr +=1
    if opgnr == (opg_antall):
        break
total_poeng = (riktig_antall*antall_poeng)- (feil_antall* minuspoeng_antall)
print("Du har prøvd %s ganger. Du har %s feil svar og %s riktige svar." % (riktig_antall+ feil_antall), feil_antall, riktig_antall)

