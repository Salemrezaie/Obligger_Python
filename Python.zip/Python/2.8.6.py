#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 18 22:14:54 2019

@author: salemrezaie
"""

print(list(range(0,10)))
print(list(range(0,7,2)))
print(list(range(2,4,6)))
print(list(range(5,18,3)))
print(list(range(-2,4,2)))
