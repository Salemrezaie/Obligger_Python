#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 16 15:58:27 2019

@author: salemrezaie
"""

In []:
    tall1=float(input("Skriv tall 1:"))
    tall2=float(input("Skriv tall 2:"))
    tall3=float(input("Skriv tall 3:"))
    maxverdi=max(tall1, tall2, tall3)
    if maxverdi==tall1:
        vinner="tall 1"
    elif maxverdi==tall2:
        vinner="tall 2"
    elif maxverdi==tall3:
        vinner="tall 3"
    print("Vinneren er", vinner,"med verdien", maxverdi)